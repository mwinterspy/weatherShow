<?php

    class Clima{
        public $lat;
        public $lon;
        public $atualizacao;
        public $temperatura; 
        public $cidade;
        public $humidade;
        public $direcaoVento;
        public $velocidadeVento;
        public $descricao;
        public $temperaturaMinima;
        public $temperaturaMaxima;
        public $icone;
        public $sunrise;
        public $sunset;
    }


?>